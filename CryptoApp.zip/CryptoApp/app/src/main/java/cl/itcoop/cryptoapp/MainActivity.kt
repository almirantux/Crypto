package cl.itcoop.cryptoapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.viewModels
import androidx.core.view.isVisible
import androidx.lifecycle.Observer

import cl.itcoop.cryptoapp.databinding.ActivityPresentaCryptoBinding
import cl.itcoop.cryptoapp.viewmodel.CryptoViewModel
import com.google.gson.annotations.SerializedName
import retrofit2.http.Url
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPresentaCryptoBinding
    private val cryptoViewModel: CryptoViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPresentaCryptoBinding.inflate(layoutInflater)
        setContentView(binding.root)
            cryptoViewModel.onCreate()
            cryptoViewModel.cryptoModel.observe( this, Observer {
                binding.tvCrypto.text = it.id
                binding.tvCurrency.text = it.currency
                binding.tvName.text = it.name
                binding.tvLogo_url.text = it.logo_url
                binding.tvStatus.text = it.status
                binding.tvPrice.text = it.price
                binding.tvPrice_date.text = it.price_date
                binding.tvPrice_timestamp.text = it.price_timestamp
                binding.tvRank.text = it.rank

            }  )
            cryptoViewModel.isLoading.observe(this, Observer {
                binding.loading.isVisible = it
            })
            binding.viewContaRec.setOnClickListener { cryptoViewModel.randomCrypto() }
        }


}