package cl.itcoop.cryptoapp.model


import retrofit2.Call
import retrofit2.Response
//import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Path



interface ApiService {
    @GET("general/")
    fun getAllCryptos(): Response<List<Cryptos>>

    @GET("details/{id}")
    fun getCryptoById(@Path("id") id: Int): Call<Cryptos>


}