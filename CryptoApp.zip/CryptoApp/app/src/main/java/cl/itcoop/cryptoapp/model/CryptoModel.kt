package cl.itcoop.cryptoapp.model

import com.google.gson.annotations.SerializedName
import retrofit2.http.Url
import java.util.*

data class CryptoModel(
    @SerializedName("id") val id: String,
    @SerializedName("currency") val currency: String,
    @SerializedName("name") val name: String,
    @SerializedName("logo_url") val logo_url: Url,
    @SerializedName("status") val status: String,
    @SerializedName("price") val price: Number,
    @SerializedName("price_date") val price_date: Date,
    @SerializedName("price_timestamp") val price_timestamp: Date,
    @SerializedName("rank") val rank: Int


)
