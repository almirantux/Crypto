package cl.itcoop.cryptoapp.model

class CryptoProvider {
    companion object {
        var cryptos:List<CryptoModel> = emptyList()
    }
}
