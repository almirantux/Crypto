package cl.itcoop.cryptoapp.model



class CryptoRepository {
    private val api = CryptoService()

    suspend fun getAllCryptos():List<CryptoModel>{
        val response = api.getCryptos()
        CryptoProvider.cryptos = response
        return response
    }

}