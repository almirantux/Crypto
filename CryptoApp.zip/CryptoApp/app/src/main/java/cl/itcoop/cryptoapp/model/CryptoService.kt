package cl.itcoop.cryptoapp.model


import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext


class CryptoService {
    private val retrofit = RetrofitHelper.getRetrofit()
    suspend fun getCryptos(): List<CryptoModel> {
        return withContext(Dispatchers.IO) {
            val response = retrofit.create(ApiService::class.java).getAllCryptos()
            (response.body() ?: emptyList()) as List<CryptoModel>
        }
    }
}