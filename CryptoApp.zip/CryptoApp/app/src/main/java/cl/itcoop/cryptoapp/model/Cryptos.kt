package cl.itcoop.cryptoapp.model

import retrofit2.http.Url
import java.util.*




class Cryptos (var id:String, var currency:String, var symbol:String, var name:String, var logo_url: Url,
               var status:String, var price: Number, var price_date: Date, var price_timestamp:Date, var rank: Int)
