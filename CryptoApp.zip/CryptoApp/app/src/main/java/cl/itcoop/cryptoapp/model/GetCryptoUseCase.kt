package cl.itcoop.cryptoapp.model



class GetCryptoUseCase {
    private val repository = CryptoRepository()
    suspend operator fun invoke() = repository.getAllCryptos()
}
