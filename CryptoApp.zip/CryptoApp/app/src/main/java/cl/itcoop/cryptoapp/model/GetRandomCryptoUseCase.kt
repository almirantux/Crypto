package cl.itcoop.cryptoapp.model

import cl.itcoop.cryptoapp.model.CryptoModel
import cl.itcoop.cryptoapp.model.CryptoProvider

class GetRandomCryptoUseCase {
    operator fun invoke(): CryptoModel?{
        val cryptos = CryptoProvider.cryptos
        if(!cryptos.isNullOrEmpty()){
            val randomNumber = (cryptos.indices).random()
            return cryptos[randomNumber]
        }
        return null
    }
}