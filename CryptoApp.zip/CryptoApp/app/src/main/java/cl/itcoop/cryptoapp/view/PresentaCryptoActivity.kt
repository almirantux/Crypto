package cl.itcoop.cryptoapp.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.viewModels
import androidx.core.view.isVisible
import androidx.lifecycle.Observer
import cl.itcoop.cryptoapp.viewmodel.CryptoViewModel
import cl.itcoop.cryptoapp.databinding.ActivityPresentaCryptoBinding

class PresentaCryptoActivity : AppCompatActivity() {
    private lateinit var binding: ActivityPresentaCryptoBinding
    private val cryptoViewModel: CryptoViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPresentaCryptoBinding.inflate(layoutInflater)
        setContentView(binding.root)
        cryptoViewModel.onCreate()
        cryptoViewModel.recetaModel.observe( this, Observer {
                binding.tvCrypto.text = it.titulo
                binding.tvCaracteristica.text = it.caracteristica
                binding.tvEnlace.text = it.enlace
            }  )
        cryptoViewModel.isLoading.observe(this, Observer {
            binding.loading.isVisible = it
        })
        binding.viewContaRec.setOnClickListener { cryptoViewModel.randomCrypto() }
    }
}