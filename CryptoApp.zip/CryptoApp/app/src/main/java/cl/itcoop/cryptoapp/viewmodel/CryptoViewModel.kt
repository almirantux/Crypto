package cl.itcoop.cryptoapp.viewmodel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import cl.itcoop.cryptoapp.model.CryptoModel
import cl.itcoop.cryptoapp.model.GetCryptoUseCase
import cl.itcoop.cryptoapp.model.GetRandomCryptoUseCase
import kotlinx.coroutines.launch

class CryptoViewModel : ViewModel() {
    val cryptoModel = MutableLiveData<CryptoModel>()
    val isLoading = MutableLiveData<Boolean>()
    var getCryptoUseCase = GetCryptoUseCase()
    var getRandomCryptoUseCase = GetRandomCryptoUseCase()
    fun onCreate() {
        viewModelScope.launch {
            isLoading.postValue(true)
            val result = getCryptoUseCase()
            Log.d("Información","se crea el viewmodel" )
            if(!result.isNullOrEmpty()){
                cryptoModel.postValue(result[0])
                isLoading.postValue(false)
            }
        }
    }
    fun randomCrypto() {
        isLoading.postValue(true)
        val crypto = getRandomCryptoUseCase()
        if(crypto!=null){
            Log.d("Información","Crypto" )
            cryptoModel.postValue(crypto!!)
        }
        isLoading.postValue(false)
    }
}










